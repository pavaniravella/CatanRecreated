package model;

public interface Port {
    public int tradeRatioXto1ForResource(Resource resourceOffering);
}
