package model;

public enum Direction {
    ZERO, ONE, TWO, THREE, FOUR, FIVE

}
