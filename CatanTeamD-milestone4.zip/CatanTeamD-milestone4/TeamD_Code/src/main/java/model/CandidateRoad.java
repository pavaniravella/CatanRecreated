package model;

public class CandidateRoad {

    PlayerColor color;
    int length;

    public CandidateRoad(PlayerColor color, int length) {
        this.color = color;
        this.length = length;
    }

}
