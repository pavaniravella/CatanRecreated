package control;

public enum GameStartState {
    BEGINNER, ADVANCED, CUSTOM
}
