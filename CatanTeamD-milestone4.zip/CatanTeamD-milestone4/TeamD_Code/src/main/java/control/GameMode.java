package control;

public enum GameMode {
    NORMAL, FOG
}
