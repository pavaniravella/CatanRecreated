package exception;


public class TooFewItemsException  extends RuntimeException {

}
