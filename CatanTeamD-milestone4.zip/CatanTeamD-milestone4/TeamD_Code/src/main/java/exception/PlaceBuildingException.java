package exception;

public class PlaceBuildingException extends RuntimeException {

    public PlaceBuildingException(String string) {
        super(string);
    }
}
