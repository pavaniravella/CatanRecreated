package exception;

public class InvalidPortPositionException extends RuntimeException {

}
