package exception;

public class InvalidHexPositionException extends RuntimeException {

}
