package exception;

public class InvalidIntersectionPositionException extends RuntimeException {

}
