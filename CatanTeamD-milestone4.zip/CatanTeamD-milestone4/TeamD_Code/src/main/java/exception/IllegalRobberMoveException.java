package exception;

public class IllegalRobberMoveException extends RuntimeException {

}
