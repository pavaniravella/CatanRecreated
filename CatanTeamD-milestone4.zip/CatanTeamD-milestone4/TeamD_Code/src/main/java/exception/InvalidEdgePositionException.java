package exception;

public class InvalidEdgePositionException extends RuntimeException {

}
