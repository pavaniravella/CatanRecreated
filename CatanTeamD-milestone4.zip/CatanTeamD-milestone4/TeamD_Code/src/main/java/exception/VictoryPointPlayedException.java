package exception;

public class VictoryPointPlayedException extends RuntimeException {
    public VictoryPointPlayedException(String message) {
        super(message);
    }
}
